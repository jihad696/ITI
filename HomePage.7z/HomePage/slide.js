document.addEventListener("DOMContentLoaded", () => {
    const slides = document.querySelector(".slides"); 
    const slideItems = document.querySelectorAll(".slide"); 

    let currentSlide = 0; 

    const updateSlidePosition = () => {
        const slideWidth = 100; 
        slides.style.transform = `translateX(-${currentSlide * slideWidth}%)`; 
    };

    const moveToNextSlide = () => {
        if (currentSlide < slideItems.length - 1) {
            currentSlide++;
        } else {
            currentSlide = 0; 
        }
        updateSlidePosition();
    };

    setInterval(moveToNextSlide, 2000); 
});
document.addEventListener("DOMContentLoaded", () => {
    const homeLink = document.getElementById("home-bar"); 
    const sidebar = document.querySelector(".sidebar-bar"); 

    homeLink.addEventListener("click", () => {
        sidebar.classList.toggle("open"); 
    });
});
